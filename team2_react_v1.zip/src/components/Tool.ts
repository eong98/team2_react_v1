import axios from 'axios';
import type { KeyboardEvent } from 'react';

const getIP = () => {
  // return "localhost";
  return "10.1.205.119"; // 학원
  return "1.201.122.5"; // 학원
}

const getCopyright = () => {
  return "Team2";
}

const getNowDate = () => {
      // 현재 날짜와 시간을 가져옵니다.
    const now = new Date();

    // 날짜와 시간을 "YYYY-MM-DD HH:mm:ss" 형식으로 변환합니다.
    const rdate = now.toLocaleString('ko-KR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    }).replace(/\./g, '-').replace(/- /g, '-').replace(/ /, ' ').trim().slice(0, -1);

    return rdate.replace(/-([0-9]{2}:)/, ' $1'); // 2024-11-06 16:29:5
}

// 포커스 이동
function enter_chk(e: React.KeyboardEvent<HTMLInputElement> | KeyboardEvent, nextTag: string){
  if(e.key === 'Enter'){ // 엔터키
    e.preventDefault();
    const nextElement = document.getElementById(nextTag);
    if(nextElement) {
      nextElement.focus();
    }
  }
}

function set_focus(nextTag: string){
  const nextElement = document.getElementById(nextTag);
  if(nextElement) {
    nextElement.focus();
  }
}

// Ajax 통신 패키지 설정
const axiosInstance = axios.create({
    // 개발 환경과 배포 환경에 따라 baseURL 설정
    // Vite 환경 변수 사용
    // 개발 환경: http://localhost:4000
    // 배포 환경: 상대 경로 ''
    // import.meta.env.PROD : vite 자동 제공 환경 변수 true: 배포, false: 개발,
    // npm run dev: import.meta.env.PROD -> false로 자동 설정
    // npm run build: import.meta.env.PROD -> true로 자동 설정
    // '': 같은 ip에 Backend 서버가 있다는 가정하에 상대경로로 요청을 보냄.
    baseURL: import.meta.env.PROD ? '' : 'http://10.1.205.119:9100'
})


// 파일 다운로드 함수
const download = async (dir:string, filename:string, downname:string) => {
  try {
    // ① Spring Boot의 /download 엔드포인트 호출
    // dir: 폴더명, filename: 서버에 저장된 파일명, downname: 원래 파일명
    // Donwload.java 호출
    const response = await axiosInstance.get("/download", {
      params: { dir, filename, downname },  // 쿼리 파라미터 전달
      responseType: "blob",                 // 응답을 binary(blob)로 받기
    });

    // ② 서버에서 받은 데이터를 Blob(바이너리) 객체로 생성
    const blob = new Blob([response.data]);

    // ③ Blob 데이터를 브라우저가 다운로드할 수 있는 URL로 변환
    const url = window.URL.createObjectURL(blob);

    // ④ 임시로 <a> 태그를 만들어서 클릭 이벤트를 트리거
    const link = document.createElement("a");
    link.href = url;                // Blob 데이터의 URL 지정
    link.download = downname;       // 실제 저장될 파일 이름 지정

    // ⑤ <a> 태그를 문서에 추가하고, 강제로 클릭해서 다운로드 실행
    document.body.appendChild(link);
    link.click();

    link.remove(); // ⑥ 클릭 후 <a> 태그 제거 
    window.URL.revokeObjectURL(url); // Blob URL 해제(메모리 누수 방지)

  } catch (err) {
    // ⑦ 예외 처리: 다운로드 실패 시 경고 및 로그 출력
    alert("파일 다운로드 중 오류가 발생했습니다.");
    console.error(err);
  }
};

const isImage = (file1 = "") => {
  // console.log('-> file1.toLowerCase():', "ABC.jpg".toLowerCase());
  // console.log('-> file1.toLowerCase().endsWith(\'jpg\'):', "ABC.jpg".toLowerCase().endsWith('jpg'));

  if(file1 != null){
    return ['jpg', 'jpeg', 'png', 'gif','jfif','webp','avif'].some(ext => file1.toLowerCase().endsWith(ext));
  }else{
    return false;
  }
  
}


export {getIP, getCopyright, getNowDate, enter_chk, set_focus, axiosInstance, download, isImage}; 
// import {getIP, getCopyright, getNowDate, enter_chk, set_focus} from 'Tool';



